import './App.css';
import {
  BrowserRouter,
  Link,
  Switch,
  Route 
} from "react-router-dom";
import Home from './components/Home';
import About from './components/About';
import { useParams } from "react-router";
import Word from './components/Word';

function App() {
  
  
  return (
    <div className="App">
      <BrowserRouter>
      <h1>Routing Example</h1>
      <p>
        <Link to="/home">Home</Link>
         {"  |  "}
        <Link to="/about">About</Link>   
      </p>
     

      <Switch>
        <Route exact path={"/about"}> 
        <About/>
        </Route>
        <Route exact path={"/home"}> 
        <Home/>
        </Route>
        <Route exact path= {"/:word"}>
          <Word />

        </Route>
        <Route exact path= {"/:word/:color/:textcolor"}>
          <Word />
          
        </Route>
      </Switch>
    </BrowserRouter>
    </div>
  );
}

export default App;
