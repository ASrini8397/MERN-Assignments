import React from 'react'

const About = () => {
  return (
      <>
    <div>About</div>
    <h1>About Component</h1>

    </>
  )
}

export default About