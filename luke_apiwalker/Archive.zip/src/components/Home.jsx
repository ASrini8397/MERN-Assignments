import React from 'react'
import { useParams } from "react-router";

const Home = (props) => {

  return (
      <>
    
    <h1>Welcome Home</h1>
  

    </>
  )
}

export default Home