import React from 'react'
import { useParams } from "react-router";

const Word= (props) =>{
    const {word} = useParams();
    const {color}= useParams();
    const {textcolor} = useParams();
    
    return (
      <h1 style={{
          backgroundColor: `${color}`,
          color: `${textcolor}`
      }}>
           { word }</h1>
    );
  }

export default Word