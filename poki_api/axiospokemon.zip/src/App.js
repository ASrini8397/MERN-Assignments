
import './App.css';
import React, {useState,useEffect} from 'react';
import axios from 'axios';

function App() {
  const [poke, setPoki]= useState([]);
    const pokeAxios = () => {
        axios.get(' https://pokeapi.co/api/v2/pokemon/?limit=807') 
            .then(response => setPoki(response.data.results))
            .catch(err => console.log(err))
    }
  
  
  return (
    <div className="App">
      <button onClick={pokeAxios}> Fetch Pokimon </button> 

      <table>
        <thead>
          <tr>
            <th>Pokimon Name </th>
          </tr>
        </thead>
        <tbody>
        {
         poke.map((pokemon, i )=>{
           return (
             <tr >
               <td key={i}> Name: {pokemon.name} </td>
             </tr>
           )
         }) 
          }
        </tbody>
      </table>
    </div>
  );
}

export default App;
